# Confirming findings with the real Bonsai runtime

baghban's findings are grounded in Bonsai's *source*. This kit checks them
against Bonsai's *behaviour*: for each of 17 small workflows it asks baghban
for a prediction, runs the workflow with the released Bonsai packages on
.NET 8, and inspects exit codes and the files left on disk. A row says `yes`
when what Bonsai did matches what baghban said, `NO` when it does not.

A `NO` is not a failure of the kit. It means baghban's model of Bonsai (or
the kit itself) is wrong somewhere, which is exactly what the kit is for: the
first run on a Mac produced four, each one led to a fix, and the second run
confirmed all 13 cases then in the kit (see [Results](#results)).

## 1. Install .NET 8

The kit needs the .NET 8 SDK (8.0.x). It works on Intel and Apple Silicon
Macs, and on Linux.

### Recommended: Microsoft's install script

No administrator password, no Homebrew, installs into `~/.dotnet`:

```
curl -sSL https://dot.net/v1/dotnet-install.sh -o ~/dotnet-install.sh
bash ~/dotnet-install.sh --channel 8.0
```

It ends with `Installation finished successfully.` Then put .NET on your
PATH for every new terminal:

```
echo 'export DOTNET_ROOT="$HOME/.dotnet"' >> ~/.zshrc
echo 'export PATH="$HOME/.dotnet:$PATH"' >> ~/.zshrc
```

Open a **new** terminal window (⌘N) and check:

```
dotnet --list-sdks
```

It should print a line starting with `8.0.`, e.g.
`8.0.425 [/Users/you/.dotnet/sdk]`.

### Why not `brew install dotnet`

On an Intel Mac, Homebrew no longer ships prebuilt packages (Intel macOS is a
Tier 3 platform for Homebrew since September 2026), so `brew install dotnet`
downloads the .NET *source* (about 300 MB) and compiles it, which takes
hours. It also installs the newest .NET (10), not 8. If you started it,
stop it:

```
pgrep -fl "brew.*dotnet"      # lists the process numbers
kill <number> <number>
```

Messages about `Permission denied … ghostscript` or `A brew install dotnet
process has already locked …` come from that Homebrew run and can be
ignored once it is stopped.

If you already have a newer .NET (9, 10, …) and not 8, the kit still runs:
the runner is marked `RollForward=Major`.

## 2. Set up baghban

From the baghban folder (quote the path if it contains spaces):

```
cd "/path/to/baghban"
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest -q                          # 250 passed
```

**Order matters: .NET before the virtual environment.** A virtual
environment saves your PATH when it is activated and restores that copy when
it is activated again. If the window was opened before .NET was added to
`~/.zshrc`, activating (again) removes `~/.dotnet` from the PATH, and
`dotnet --list-sdks` says `command not found` even though .NET is installed.
Either open a new terminal window and activate afterwards, or add .NET to
the current window after activating:

```
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$HOME/.dotnet:$PATH"
```

## 3. Run the kit

```
dotnet --list-sdks                 # must print 8.0.x (or newer) in this window
python confirm/confirm.py
```

What happens:

1. baghban predicts each case (instant). A prediction that differs from what
   the case expects is printed as `PREDICTION MISMATCH`.
2. `dotnet build` compiles `runner/` into `runner/bin/confirm/`. The first
   time, it downloads `Bonsai.System` 2.9.x and `Bonsai.Core` from NuGet and
   prints .NET's welcome and telemetry notice (set
   `DOTNET_CLI_TELEMETRY_OPTOUT=1` to opt out). This takes a minute; later
   runs take a few seconds.
3. Each case runs in its own empty temporary folder, once or twice. Each run
   waits two seconds after the workflow completes, so Bonsai's background
   file writers can close their files (see [Results](#results)). The whole
   kit takes under a minute.
4. A table prints, and the details go to `confirm/results.json`.

Options:

```
python confirm/confirm.py --keep       # keep the run folders to open the files yourself
python confirm/confirm.py --dry-run    # predictions only, no .NET needed
```

## 4. Read the output

```
case                               baghban                observed   what happened
overwrite_across_runs              SILENT_OVERWRITE       yes        run 2 exit 0; 1 file(s) after 2 runs; rows per run [3] then [3]; content replaced: True
overwrite_with_timestamp_suffix    (quiet)                yes        run 2 exit 0; 2 file(s) after 2 runs
...
17/17 confirmed. Details: .../confirm/results.json
```

- **case**: the workflow (table below).
- **baghban**: what baghban reports for it; `(quiet)` means no finding.
  Quiet cases are the controls: they show nothing bad happens when baghban
  says nothing.
- **observed**: `yes` if Bonsai behaved as predicted, `NO` if not.
- **what happened**: exit codes, Bonsai's error message, files and rows.

`results.json` holds the same per case, with each run's exit code, full
error message and file list. Send it along when reporting a `NO`.

## The cases

| Case | baghban says | Confirmed when |
| --- | --- | --- |
| `overwrite_across_runs` | `SILENT_OVERWRITE` (warning since 0.5.0) | after two runs there is one file, holding only run 2's rows |
| `overwrite_with_timestamp_suffix` | quiet | after two runs there are two files |
| `no_overwrite_second_run_stops` | quiet | run 2 fails with "already exists" and run 1's data is intact |
| `overwrite_per_element` | `SILENT_OVERWRITE` (error) | three elements through a `SelectMany` leave one row |
| `writer_after_loop` | quiet | the same, with the writer after the loop, leaves three rows |
| `fails_on_repeat` | `FAILS_ON_REPEAT` | the run fails on the second element |
| `duplicate_output` | `DUPLICATE_OUTPUT` | the run fails, or fewer than all rows survive |
| `distinct_outputs` | quiet | two files, three rows each |
| `disabled_writer` | `DISABLED_WRITER` | the run succeeds and writes no file |
| `appends_across_runs` | `APPENDS_ACROSS_RUNS` | after two runs, one file with six rows |
| `dangling_subject` | `DANGLING_SUBJECT` | Bonsai refuses to build it |
| `unnamed_subscribe` | `UNNAMED_SUBJECT` (error) | Bonsai refuses to build the node after it |
| `unnamed_subscribe_alone` | `UNNAMED_SUBJECT` (info) | it builds, and the rest of the workflow runs |
| `duplicate_property` | `DUPLICATE_PROPERTY` | Bonsai refuses to build it ("already exists") and nothing is written (added in 0.4.1) |
| `same_property_in_two_groups` | quiet | two files, three rows each: each group has its own names (added in 0.4.1) |
| `loop_runs_once` | quiet | the three elements reduced to one by `LastOrDefault` before a `SelectMany` holding a writer (`Overwrite=False`): the run succeeds and writes one row (added in 0.6.0) |
| `loop_run_again_by_repeat` | `FAILS_ON_REPEAT` | the same loop followed by `RepeatCount(2)`: the second run of the loop finds the file and fails (added in 0.6.0) |

Every workflow is three timer ticks, 100 ms apart, through `Take(3)` and
`Timestamp`, so every case ends on its own and every run writes different
values.

## Why a runner instead of Bonsai.Player

`Bonsai.Player` does the same thing (deserialize, build, run) but references
only `Bonsai.Core`, and finds other packages through a `Bonsai.config` in its
own install folder. The writers under test live in `Bonsai.System`, so
`runner/` is the Player's `Program.cs` with that package referenced
directly. Two changes: it awaits `LastOrDefaultAsync()`, so a workflow that
completes without values is not reported as a failure, and it waits two
seconds before exiting (next section).

## Results

### First run: 29 Sep 2026, baghban 0.2.0, 8/12 confirmed

Setup for both runs: macOS 26 (Tahoe) on an Intel MacBook Pro, .NET SDK
8.0.425 installed with `dotnet-install.sh`, runner targeting `net8.0`, NuGet
packages Bonsai.Core 2.9.1, Bonsai.System 2.9.1 and System.Reactive 6.0.1
(the versions `2.9.*` resolved to, recorded in `runner/obj/project.assets.json`).

The eight confirmations include every error baghban
reports for writers inside loops, duplicate outputs and dangling subjects,
with Bonsai's own messages (`IOException: The file 'trial.csv' already
exists.`, `ArgumentException: The specified variable 'Nope' was not found in
the current build context.`), and all quiet controls that completed.

The four `NO`s, and what they taught:

- **`overwrite_across_runs`, `writer_after_loop`, `appends_across_runs`: a
  bug in the kit.** The files existed but were empty. Bonsai's file writers
  write and close on a background thread (`EventLoopScheduler`, in
  `Bonsai.System/IO/WriterDisposable.cs`); when the workflow completes,
  closing is only scheduled. The runner exited at once and the process was
  killed before the writers flushed. (The editor never exits there, which is
  why rigs do not lose data this way.) Fixed: the runner now waits two
  seconds, and the overwrite judgement requires real rows in both runs,
  since two empty files are also "unchanged".
- **`unnamed_subscribe`: a wrong claim in baghban.** baghban 0.2.0 said an
  unnamed `SubscribeSubject` builds fine and silently produces nothing.
  Bonsai refused to build: `Unsupported number of arguments. This node
  requires at least 1 input connection(s).` The unnamed subscriber builds to
  an empty expression, and Bonsai does not pass empty expressions on
  (`ExpressionBuilderGraphExtensions.cs`), so the `CsvWriter` after it had
  no input. Fixed: `UNNAMED_SUBJECT` is an error when nodes are connected
  after it, info when nothing is. This also re-classified a survey finding:
  a Berkeley rig workflow has an unnamed subscriber feeding a
  `PropertyMapping`, so it cannot build (`survey/SURVEY.md`).

### Second run: 4 Oct 2026, baghban 0.2.1, 13/13 confirmed

Same machine and packages, with the fixed runner (waits for Bonsai's writers
to close their files) and the corrected `UNNAMED_SUBJECT`. Every finding
baghban reports in these cases happened as predicted on the real Bonsai
runtime, and every quiet control ran without loss. The full record is
`confirm/results.json`.

| Case | baghban | Confirmed | What Bonsai did |
| --- | --- | --- | --- |
| `overwrite_across_runs` | `SILENT_OVERWRITE` | yes | run 2 exit 0; 1 file(s) after 2 runs; rows per run [3] then [3]; content replaced: True |
| `overwrite_with_timestamp_suffix` | quiet | yes | run 2 exit 0; 2 file(s) after 2 runs |
| `no_overwrite_second_run_stops` | quiet | yes | run 2 exit 1 (IOException: The file 'data.csv' already exists.); data kept: True |
| `overwrite_per_element` | `SILENT_OVERWRITE` | yes | exit 0; lines in file: 1 of 3 elements |
| `writer_after_loop` | quiet | yes | exit 0; lines in file: 3 of 3 elements |
| `fails_on_repeat` | `FAILS_ON_REPEAT` | yes | exit 1 (IOException: The file 'trial.csv' already exists.) |
| `duplicate_output` | `DUPLICATE_OUTPUT` | yes | exit 1 (IOException: The file 'same.csv' already exists.); 1 file(s), 0 of 6 rows |
| `distinct_outputs` | quiet | yes | exit 0; 2 file(s) with [3, 3] rows |
| `disabled_writer` | `DISABLED_WRITER` | yes | exit 0; files: none |
| `appends_across_runs` | `APPENDS_ACROSS_RUNS` | yes | after 2 runs: 1 file, 6 rows (3 per run) |
| `dangling_subject` | `DANGLING_SUBJECT` | yes | exit 1: build refused, subject not found (message below) |
| `unnamed_subscribe` | `UNNAMED_SUBJECT` | yes | exit 1: build refused, the node after it has no input (message below) |
| `unnamed_subscribe_alone` | `UNNAMED_SUBJECT` | yes | exit 0; rows written: [3] |

Bonsai's own messages, in full:

- `fails_on_repeat`: `IOException: The file 'trial.csv' already exists.` on the second element, ending the session.
- `duplicate_output`: `IOException: The file 'same.csv' already exists.` The second writer refused the file the first had created; no rows survived.
- `dangling_subject`: `ArgumentException: The specified variable 'Nope' was not found in the current build context. (Parameter 'name')`
- `unnamed_subscribe`: `WorkflowBuildException: Unsupported number of arguments. This node requires at least 1 input connection(s).`

What this run establishes, and what it does not:

- **Established:** for each finding, on Bonsai 2.9.1 packages, the behaviour
  baghban's message describes actually happens: files are replaced, sessions
  end on the second trial, builds fail with the stated cause, disabled
  writers write nothing, and each quiet control behaves normally.
- **Not established:** that every workflow baghban flags behaves like these
  minimal cases (the survey's hand review covers that question for published
  rigs), behaviour on Windows, where rigs actually run (the code paths are
  the same .NET libraries, but file locking differs between operating
  systems, which matters most for `DUPLICATE_OUTPUT`), and other Bonsai
  versions.

### Third run: 12 Oct 2026, baghban 0.4.0, 13/13 confirmed

The same 13 cases, on the same machine, with the runner changed for
`confirm_properties.py` (it now takes `NAME=VALUE` arguments; with none, it
does what it did before). Same outcomes as the second run.

### Fourth run: 12 Oct 2026, baghban 0.4.1, 15/15 confirmed

The 13 cases again, plus the two added in 0.4.1. Same machine and packages:

| Case | baghban | Confirmed | What Bonsai did |
| --- | --- | --- | --- |
| `duplicate_property` | `DUPLICATE_PROPERTY` | yes | exit 1: `WorkflowBuildException: A workflow property with the name 'Out' already exists.` |
| `same_property_in_two_groups` | quiet | yes | exit 0; 2 file(s) with [3, 3] rows |

The other 13 rows are identical to the second run's.

### Fifth run: 28 Oct 2026, baghban 0.5.0, 15/15 confirmed

The same 15 cases, after `SILENT_OVERWRITE` across runs became a warning.
The kit compares finding codes, not severities, so the predictions were
unchanged, and so were Bonsai's outcomes. The 2 cases added in 0.6.0
(`loop_runs_once`, `loop_run_again_by_repeat`) have not been run yet.

## If a case says NO

1. Re-run with `--keep` and open the files in the printed folder.
2. Read the error in `results.json` and find the behaviour in the Bonsai
   source.
3. Decide whether baghban's check (or the claim in its message) or the kit
   is wrong, fix it, add the case to `tests/test_confirm_harness.py` and
   `tests/test_checks.py`, and record it here and in the CHANGELOG.

## Confirming the package reader (0.3.0)

baghban 0.3.0 reads embedded workflows out of package DLLs with its own
pure-Python reader. `confirm_packages.py` checks that reader against
Microsoft's (`System.Reflection.Metadata`, part of .NET itself, so the
lister in `resources/` needs no packages) on real Bonsai packages:

```
python confirm/confirm_packages.py
```

For each package (by default the eight the survey most often could not
read: BonVision, AllenNeuralDynamics.Core and .HarpUtils, Aeon.Acquisition,
Bonsai.Harp, the two Bonsai.ML packages, AllenNeuralDynamics.AindManipulator)
it downloads the newest version from nuget.org into baghban's cache, takes
every DLL in it, and compares, DLL by DLL, what both readers see: the
assembly name, and every resource's name, offset, whether it is embedded,
and the SHA-256 of its bytes. Then it resolves every embedded `.bonsai`
resource the way an include would, through baghban's resolver, and checks
the extracted file is byte-for-byte what .NET read. Expected ending:

```
8/8 packages identical to .NET. Details: .../confirm/packages-results.json
```

A package nuget.org does not have is listed as "not checked", not as a
failure. Other options:

```
python confirm/confirm_packages.py BonVision=0.9.0 Bonsai.Harp   # specific packages/versions
python confirm/confirm_packages.py --dry-run                     # baghban's side only, no .NET
```

The first run builds `resources/` (a few seconds) and downloads the
packages (tens of MB, once; later runs use the cache).

### Results

**First run: 12 Oct 2026, baghban 0.3.0, macOS (Intel), .NET 8.0.425:
8/8 packages identical to .NET.** Newest versions on nuget.org that day:

| Package | Version | DLLs | Resources | Workflows | Result |
| --- | --- | ---: | ---: | ---: | --- |
| BonVision | 0.12.0 | 1 (net462) | 59 | 34 | same as .NET |
| AllenNeuralDynamics.Core | 0.5.0 | 1 (net472) | 23 | 20 | same as .NET |
| AllenNeuralDynamics.HarpUtils | 0.3.2 | 1 (net472) | 12 | 11 | same as .NET |
| Aeon.Acquisition | 0.7.0 | 1 (net472) | 22 | 22 | same as .NET |
| Bonsai.Harp | 3.6.1 | 2 (net462, netstandard2.0) | 8 | 8 | same as .NET |
| Bonsai.ML.LinearDynamicalSystems | 0.4.1 | 2 (net472, netstandard2.0) | 24 | 20 | same as .NET |
| Bonsai.ML.HiddenMarkovModels | 0.4.1 | 1 (net472) | 10 | 8 | same as .NET |
| AllenNeuralDynamics.AindManipulator | 0.4.1 | 1 (net48) | 7 | 6 | same as .NET |

For all 10 DLLs, baghban and System.Reflection.Metadata agree on the
assembly name and on every one of the 165 resources: name, offset, embedded
or not, and SHA-256 of the bytes. Every embedded workflow addressable by
an include (named after its assembly) was also resolved through baghban as
an include would resolve it, and came out byte-for-byte identical. Full record: `packages-results.json`.

Before this, the reader had matched dnfile, an independent Python parser,
on 168 real assemblies from PyPI (a .NET runtime and pythonnet), including
large assemblies with 4-byte heaps.

## Confirming launcher values (0.4.0)

baghban 0.4.0 records the values a launcher passes with
`Bonsai.exe rig.bonsai -p:Stim.RF.FileNameRF=c.csv` (`baghban.provenance`),
and applies them so checks see what the session ran with
(`baghban.set_properties`). The record is only worth keeping if each value
goes where Bonsai sends it. `confirm_properties.py` checks that on the real
runtime:

```
python confirm/confirm_properties.py
```

For each of 11 cases it writes a small workflow (and the include file it
needs), asks baghban either which files the session will write or which
name Bonsai will refuse, then runs it with the runner, which now applies
`NAME=VALUE` arguments exactly as Bonsai.exe applies `--property`: build,
`SetWorkflowProperty` for each, run (Bonsai.Editor/WorkflowRunner.cs). Each
value is a CsvWriter's file name, so where it went is visible on disk.

| Case | Values | baghban says |
| --- | --- | --- |
| `top_level` | `Out=a.csv` | writes `a.csv` |
| `through_a_group` | `Rec.Log=b.csv` | writes `b.csv` |
| `through_a_named_selectmany` | `Trial.Log=e.csv` | writes `e.csv`: any named nested workflow, not only groups |
| `groups_then_include_then_group` | `Stim.RF.FileNameRF=c.csv` | writes `c.csv`: iblrig's shape, through two groups, into an include, into a group inside it |
| `include_value_reaches_group` | (none) | writes `left.csv`, the value saved on the include; 0.3.0 said `noise.csv` |
| `two_properties_same_name` | `Out=z.csv` | refused: `WorkflowBuildException` (two properties named `Out` in one workflow; the build fails before any value is set) |
| `same_name_in_two_groups` | `Left.Out=z.csv` | writes `z.csv` and `r.csv`: each group has its own names |
| `unknown_name` | `Nope=x.csv` | refused: `KeyNotFoundException` |
| `ambiguous_group` | `Rec.Log=x.csv` | refused: `InvalidOperationException` (two groups named `Rec`) |
| `disabled_group` | `Off.Log=x.csv` | refused: `KeyNotFoundException` (a disabled group is not a workflow) |
| `include_by_name` | `RF.FileNameRF=x.csv` | refused: `KeyNotFoundException` (an include is reached only through a mapping) |

Expected ending: `11/11 confirmed. Details: .../confirm/properties-results.json`.
`--dry-run` checks baghban's side only. The name rules were read from the
Bonsai source and are identical from 2.6.2 to 2.9.1 (`SetWorkflowProperty`);
the runner uses the 2.9 packages, like the other kits.

### Results

**First run: 12 Oct 2026, baghban 0.4.0 (before the fix below), macOS
(Intel), Bonsai 2.9 packages: 9/10 confirmed.** All five cases where a value
goes somewhere wrote exactly the predicted file, including iblrig's shape
(two groups, an include, a group inside it) and the value saved on an
include reaching a group inside it, which 0.3.0 got wrong. All four refusals
happened with the predicted exception.

The NO was `first_of_two_same_names`. baghban said that of two properties
named `Out` in one workflow, the first receives the value. Bonsai never got
that far:

```
WorkflowBuildException: A workflow property with the name 'Out' already exists.
```

Bonsai.exe builds the workflow before it assigns any value, and the build
registers every externalized property name of each workflow, refusing a
repeat (`RegisterPropertyName` in `ExpressionBuilderGraphExtensions.cs`, the
same in 2.6.2). So such a workflow never runs, launcher or not. Fixed in
0.4.1:
- `set_properties` reports the name as `duplicate`.
- `check` reports the new error `DUPLICATE_PROPERTY`, with two cases in
  `confirm.py`.
- The case is now `two_properties_same_name`, predicting the refusal, with a
  quiet twin `same_name_in_two_groups`.

None of the 572 survey workflows has such a pair.

**Second run: 12 Oct 2026, baghban 0.4.1, same machine: 11/11 confirmed.**

| Case | baghban says | Confirmed | What Bonsai did |
| --- | --- | --- | --- |
| `top_level` | writes `a.csv` | yes | wrote `a.csv` |
| `through_a_group` | writes `b.csv` | yes | wrote `b.csv` |
| `through_a_named_selectmany` | writes `e.csv` | yes | wrote `e.csv` |
| `groups_then_include_then_group` | writes `c.csv` | yes | wrote `c.csv` |
| `include_value_reaches_group` | writes `left.csv` | yes | wrote `left.csv` |
| `two_properties_same_name` | refused (`WorkflowBuildException`) | yes | `WorkflowBuildException: A workflow property with the name 'Out' already exists.` |
| `same_name_in_two_groups` | writes `r.csv`, `z.csv` | yes | wrote `r.csv`, `z.csv` |
| `unknown_name` | refused (`KeyNotFoundException`) | yes | `KeyNotFoundException: No property or named element 'Nope' was found in the workflow.` |
| `ambiguous_group` | refused (`InvalidOperationException`) | yes | `InvalidOperationException: Multiple elements with the specified name 'Rec' were found in the workflow.` |
| `disabled_group` | refused (`KeyNotFoundException`) | yes | `KeyNotFoundException: No property or named element 'Off.Log' was found in the workflow.` |
| `include_by_name` | refused (`KeyNotFoundException`) | yes | `KeyNotFoundException: No property or named element 'RF.FileNameRF' was found in the workflow.` |

What this establishes, and what it does not:

- **Established:** on Bonsai 2.9 packages, a launcher value goes where
  baghban says. That holds at the top level, through named groups and
  other nested workflows, and through a group into an include and a group
  inside it. Each name baghban reports as refused is refused, with the
  stated exception. So `bonsai.property.*` and `bonsai.param.*` in a
  provenance record describe what the session ran with.
- **Not established:** values that need type conversion (baghban keeps
  values as strings, and a value that does not convert fails only when
  Bonsai runs). Also not tested: Bonsai.exe's own command-line parser,
  which baghban mirrors from source and tests in `tests/test_launch.py`
  (the runner takes `NAME=VALUE` directly); other Bonsai versions; and
  Windows.

## Troubleshooting

| Symptom | Cause and fix |
| --- | --- |
| `dotnet not found` from `confirm.py`, or `zsh: command not found: dotnet` | .NET is not on this window's PATH: open a new window, or run the two `export` lines above after activating the virtual environment |
| `dotnet --list-sdks` works in one window but not another | the other window was opened, or its virtual environment activated, before `~/.zshrc` was changed |
| `brew install dotnet` compiles for hours | Intel Mac: use the install script instead and stop the Homebrew process |
| `You must install or update .NET to run this application` | only a newer .NET is installed and an old copy of the runner is used: delete `confirm/runner/bin` and `confirm/runner/obj` and re-run |
| `NU1101` / cannot find package `Bonsai.System` | no internet access to nuget.org during the first build |
| `confirm_packages.py`: "not checked: ... CERTIFICATE_VERIFY_FAILED" | the python.org installer on macOS has no certificates: run `Install Certificates.command` from your Python folder once |
| `confirm_packages.py`: a package "not checked: ... has no package" | that package is not on nuget.org (it may come from a private feed: set `BAGHBAN_NUGET_SOURCE`) |
| Every case `NO` with empty files | the runner exited before writers flushed: make sure `runner/Program.cs` has the `Task.Delay` after the workflow completes |
